#
# TABLE STRUCTURE FOR: client_antrian
#

DROP TABLE IF EXISTS `client_antrian`;

CREATE TABLE `client_antrian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` int(5) NOT NULL,
  `status` int(1) NOT NULL,
  `pin` int(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `client` (`client`)
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=latin1;

INSERT INTO `client_antrian` (`id`, `client`, `status`, `pin`) VALUES (126, 1, 2, 12345);
INSERT INTO `client_antrian` (`id`, `client`, `status`, `pin`) VALUES (127, 2, 1, 12344);


#
# TABLE STRUCTURE FOR: data_antrian
#

DROP TABLE IF EXISTS `data_antrian`;

CREATE TABLE `data_antrian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `counter` int(11) NOT NULL,
  `waktu` text NOT NULL,
  `status` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `counter` (`counter`),
  CONSTRAINT `data_antrian_ibfk_1` FOREIGN KEY (`counter`) REFERENCES `client_antrian` (`client`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=latin1;

INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (1, 1, '', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (2, 2, '', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (3, 2, '', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (4, 2, '', 4, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (5, 2, '1574586656', 4, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (6, 2, '1574586676', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (7, 1, '1574590825', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (8, 2, '1574590835', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (9, 1, '1574591243', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (10, 1, '1574592856', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (11, 2, '1574592950', 4, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (12, 2, '1574592972', 1, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (13, 1, '1574593182', 3, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (14, 2, '1574593802', 0, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (15, 2, '1574593817', 3, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (16, 2, '1574593982', 3, 0);
INSERT INTO `data_antrian` (`id`, `counter`, `waktu`, `status`, `type`) VALUES (17, 2, '1574594040', 3, 0);


#
# TABLE STRUCTURE FOR: tbl_icons
#

DROP TABLE IF EXISTS `tbl_icons`;

CREATE TABLE `tbl_icons` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(35) NOT NULL,
  `code` varchar(128) NOT NULL,
  `kategori` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (1, 'dashoard', '<i class=\"fas fa-fw fa-tachometer-alt\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (2, 'setting circle', '<i class=\"fas fa-fw fa-cog\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (3, 'setting', '<i class=\"fas fa-fw fa-wrench\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (4, 'folder', '<i class=\"fas fa-fw fa-folder\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (5, 'Chart', '<i class=\"fas fa-fw fa-chart-area\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (6, 'Tables', '<i class=\"fas fa-fw fa-table\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (7, 'Celender', '<i class=\"fas fa-calendar fa-2x text-gray-300\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (8, 'Dollars', '<i class=\"fas fa-dollar-sign fa-2x text-gray-300\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (9, 'Clipboard List', '<i class=\"fas fa-clipboard-list\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (10, 'Comments', '<i class=\"fas fa-comments\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (11, 'Key Password', '<i class=\"fas fa-fw fa-key\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (12, 'User', '<i class=\"fas fa-fw fa-user\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (13, 'User edit', '<i class=\"fas fa-fw fa-user-edit\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (14, 'folder open', '<i class=\"fas fa-fw fa-folder-open\"></i>', '');
INSERT INTO `tbl_icons` (`id`, `name`, `code`, `kategori`) VALUES (15, 'user Tie', '<i class=\"fas fa-fw fa-user-tie\"></i>', '');


#
# TABLE STRUCTURE FOR: tbl_setting
#

DROP TABLE IF EXISTS `tbl_setting`;

CREATE TABLE `tbl_setting` (
  `id` varchar(6) NOT NULL,
  `name` varchar(49) NOT NULL,
  `title` varchar(180) NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `tbl_setting` (`id`, `name`, `title`, `status`) VALUES ('STNG01', 'theme_admin', 'default', '1');
INSERT INTO `tbl_setting` (`id`, `name`, `title`, `status`) VALUES ('STNG02', 'background_color', 'white', '1');
INSERT INTO `tbl_setting` (`id`, `name`, `title`, `status`) VALUES ('STNG03', 'data_color', 'azure', '1');
INSERT INTO `tbl_setting` (`id`, `name`, `title`, `status`) VALUES ('STNG04', 'background_image', 'http://localhost/penelitian/themes/default/assets/img/sidebar-1.jpg', '1');
INSERT INTO `tbl_setting` (`id`, `name`, `title`, `status`) VALUES ('STNG05', 'theme_public', 'irsan', '1');


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` varchar(9) NOT NULL,
  `nip` varchar(89) NOT NULL,
  `name` varchar(25) DEFAULT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` int(3) NOT NULL,
  `is_active` int(1) NOT NULL,
  `menu_active` enum('yes','no') NOT NULL DEFAULT 'no',
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id_user`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `tbl_user_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user` (`id_user`, `nip`, `name`, `email`, `password`, `role_id`, `is_active`, `menu_active`, `date_created`) VALUES ('user_001', '', 'Irsan_mansyur', 'portofolio@gmail.com', '$2y$10$kH0w9I69YWjHkMN1l/1.J.BR9E4d0JXV5Hb1buOjN2x3.TAaXcMRS', 1, 1, 'yes', 1567261992);
INSERT INTO `tbl_user` (`id_user`, `nip`, `name`, `email`, `password`, `role_id`, `is_active`, `menu_active`, `date_created`) VALUES ('user_002', '161290', NULL, 'irsan00mansyur@gmail.com', '$2y$10$EVU9J1/muGz.KQrIwWMuBeMID4Q1HN0wgH1hXN0n924.9NK87d0vq', 2, 1, 'yes', 1572874871);
INSERT INTO `tbl_user` (`id_user`, `nip`, `name`, `email`, `password`, `role_id`, `is_active`, `menu_active`, `date_created`) VALUES ('user_003', '', NULL, 'irsanfile@gmail.com', '$2y$10$qBURYcfGw/ATn9aQfZitt.viFOmCxFuAWlSK.YnVQe2wqj5f2N.zK', 2, 1, 'no', 1573742479);


#
# TABLE STRUCTURE FOR: tbl_user_about
#

DROP TABLE IF EXISTS `tbl_user_about`;

CREATE TABLE `tbl_user_about` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(46) NOT NULL,
  `image` varchar(300) NOT NULL,
  `motivasi` varchar(400) NOT NULL,
  `pekerjaan` varchar(300) NOT NULL,
  `tentang_saya` varchar(1000) NOT NULL,
  `id_gallery` int(5) NOT NULL,
  `user_id` varchar(9) CHARACTER SET utf8 NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `nip` varchar(10) NOT NULL,
  `situs` varchar(188) NOT NULL,
  `alamat` varchar(288) NOT NULL,
  `tgl_lahir` int(12) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_about_ibfk_1` (`user_id`),
  CONSTRAINT `tbl_user_about_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbl_user` (`id_user`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_user_about` (`id`, `name`, `image`, `motivasi`, `pekerjaan`, `tentang_saya`, `id_gallery`, `user_id`, `no_hp`, `nip`, `situs`, `alamat`, `tgl_lahir`) VALUES (1, 'Admin WEB', '00011.jpg', 'Tak Ada usaha yang menghianati hasil. Yakinlah semakin besar usahamu, semakin besar kamu mencapai impianmu.', 'Petani|Guru Honorer|Pegawai', '&quot;Tak Ada usaha yang menghianati hasil. Yakinlah semakin besar usahamu, semakin besar kamu mencapai impianmu&quot;', 1, 'user_001', '085298198343', '161290', 'http://www.irsandp.com', 'Kamp. Sarroanging, Desa Mappilawing, Kec. eremerasa, Kab. Bantaeng', 666637200);
INSERT INTO `tbl_user_about` (`id`, `name`, `image`, `motivasi`, `pekerjaan`, `tentang_saya`, `id_gallery`, `user_id`, `no_hp`, `nip`, `situs`, `alamat`, `tgl_lahir`) VALUES (7, 'Irsan Mansyur', '0001.jpg', '', '', 'Saya adalh seorang mahasiswa di STMIK Dipanegara Makasar jurusan Sistem Informasi,\r\nsaat ini saya sedag mengerjakan tugas akhir yakni SKRIPSI sebagai sarana untuk lulus kuliah S1', 0, 'user_002', '085298884534', '', 'www.google.com', 'Kamp. sarroanging, Desa Mappilawing', 835462800);
INSERT INTO `tbl_user_about` (`id`, `name`, `image`, `motivasi`, `pekerjaan`, `tentang_saya`, `id_gallery`, `user_id`, `no_hp`, `nip`, `situs`, `alamat`, `tgl_lahir`) VALUES (10, 'Irsan Mansyurn', '', '', '', '', 0, 'user_003', '085298884534', '', '', 'Kamp. sarroanging, Desa Mappilawing', 658515600);


#
# TABLE STRUCTURE FOR: tbl_user_access_menu
#

DROP TABLE IF EXISTS `tbl_user_access_menu`;

CREATE TABLE `tbl_user_access_menu` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `role_id` int(2) NOT NULL,
  `menu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `tbl_user_access_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `tbl_user_menu` (`id_menu`),
  CONSTRAINT `tbl_user_access_menu_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `tbl_user_role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (60, 1, 1);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (61, 1, 2);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (62, 2, 2);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (70, 1, 9);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (72, 2, 24);
INSERT INTO `tbl_user_access_menu` (`id`, `role_id`, `menu_id`) VALUES (74, 1, 24);


#
# TABLE STRUCTURE FOR: tbl_user_menu
#

DROP TABLE IF EXISTS `tbl_user_menu`;

CREATE TABLE `tbl_user_menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `menu` varchar(88) NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (1, 'admin');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (2, 'user');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (9, 'Menu Managements');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (24, 'Antrian');
INSERT INTO `tbl_user_menu` (`id_menu`, `menu`) VALUES (27, 'Petugas');


#
# TABLE STRUCTURE FOR: tbl_user_role
#

DROP TABLE IF EXISTS `tbl_user_role`;

CREATE TABLE `tbl_user_role` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_role` (`id`, `name`) VALUES (1, 'Administrator');
INSERT INTO `tbl_user_role` (`id`, `name`) VALUES (2, 'User');
INSERT INTO `tbl_user_role` (`id`, `name`) VALUES (13, 'Petugas');


#
# TABLE STRUCTURE FOR: tbl_user_sub_menu
#

DROP TABLE IF EXISTS `tbl_user_sub_menu`;

CREATE TABLE `tbl_user_sub_menu` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon_id` int(6) NOT NULL DEFAULT 10,
  `is_active` int(1) NOT NULL,
  `class` varchar(120) NOT NULL,
  `method` varchar(122) NOT NULL,
  `akses` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `menu_id` (`menu_id`),
  KEY `icon_id` (`icon_id`),
  CONSTRAINT `tbl_user_sub_menu_ibfk_1` FOREIGN KEY (`menu_id`) REFERENCES `tbl_user_menu` (`id_menu`),
  CONSTRAINT `tbl_user_sub_menu_ibfk_2` FOREIGN KEY (`icon_id`) REFERENCES `tbl_icons` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (45, 1, 'Role Acces', 'admin/admin/role', 3, 1, 'admin', 'role', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (50, 2, 'Profile User', 'admin/user/profile', 15, 1, 'user', 'profile', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (51, 9, 'Menu Akses', 'admin/menu', 4, 1, 'menu', 'index', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (52, 9, 'Sub Menu ', 'admin/menu/submenu', 14, 1, 'menu', 'submenu', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (54, 2, 'Change Password', 'admin/user/changepassword', 13, 1, 'user', 'changepassword', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (56, 2, 'User Blocked', 'admin/user/blocked', 11, 1, 'user', 'blocked', 1);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (57, 24, 'Admin Antrian', 'admin/antrian/admin', 15, 1, 'antrian', 'admin', 0);
INSERT INTO `tbl_user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon_id`, `is_active`, `class`, `method`, `akses`) VALUES (58, 24, 'Loket', 'admin/antrian/loket', 5, 1, 'antrian', 'loket', 0);


#
# TABLE STRUCTURE FOR: tbl_user_token
#

DROP TABLE IF EXISTS `tbl_user_token`;

CREATE TABLE `tbl_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(128) NOT NULL,
  `token` varchar(128) NOT NULL,
  `date_created` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tbl_visitor
#

DROP TABLE IF EXISTS `tbl_visitor`;

CREATE TABLE `tbl_visitor` (
  `id_visitor` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `os` varchar(30) NOT NULL,
  `browser` varchar(130) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_visitor`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (1, '::1', 'Windows 7', 'Google Chrome v.78.0.3904.87', '2019-11-12 13:55:56');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (2, '778', 'ghghj', 'hgjhg', '2019-08-09 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (3, 'khjh', 'hjhj', 'jh', '2019-11-21 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (4, 'ok', 'hjh', 'h', '2019-11-01 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (5, 'ihu', 'ghhg', 'ggh', '2019-11-01 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (6, 'ihjk', 'gjhg', 'gjh', '2019-11-13 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (7, 'uig', 'yjghj', 'ghj', '2019-11-13 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (8, 'ada ', 'ada', 'ad', '2019-11-22 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (9, 'ada', 'ad', 'ad', '2019-11-22 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (10, 'ada', 'ada', 'ada', '2019-11-23 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (11, 'ad', 'ada', 'ada', '2019-11-24 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (12, 'h', 'jh', 'h', '2019-11-24 00:00:00');
INSERT INTO `tbl_visitor` (`id_visitor`, `ip`, `os`, `browser`, `date_created`) VALUES (13, 'ad', 'a', 'da', '2019-11-26 00:00:00');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (1, 'Frans', '', 'frans', '123');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (2, 'admin', '', 'admin', 'admin');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (3, 'Ambarita', 'franscodes@gmail.com', 'batak', '123');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (4, 'ssad', 'sdasd', 'asd', '123');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (5, 'Hafidz', 'wandrifo@gmail.com', 'hafidz', '123');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (6, 'Miyan Yesica', 'miyan yesica', 'miyan', '123');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (7, 'Indah Siska', 'indah@gmail.com', 'indah', 'indah');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (8, 'cindy', 'cindy', 'cindy', '123');
INSERT INTO `user` (`id_user`, `nama`, `email`, `username`, `password`) VALUES (9, 'Frans Ambarita', 'frans@gmail.com', 'ambaritafrans', '123');


